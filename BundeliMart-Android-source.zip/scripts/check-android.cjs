const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const base=path.join(__dirname,'../android/app/src/main/assets/www');
const storage=new Map(),els={};
function boot(){
 const document={getElementById:id=>els[id]??=({innerHTML:'',textContent:'',value:'',hidden:false,classList:{add(){},remove(){}},addEventListener(){},showModal(){},close(){}}),querySelectorAll:()=>[],addEventListener(){}};
 const ctx=vm.createContext({document,window:{},Intl,Map,Set,localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},setTimeout:()=>0,clearTimeout(){}});
 for(const f of ['catalog.js','app.js'])vm.runInContext(fs.readFileSync(path.join(base,f),'utf8'),ctx);
 return ctx;
}
let ctx=boot();
assert.equal((els.products.innerHTML.match(/<article/g)||[]).length,38);
vm.runInContext('for(const p of products) if(!p.image) throw Error("missing image")',ctx);
for(const image of vm.runInContext('products.map(p=>p.image)',ctx))assert.ok(fs.existsSync(path.join(base,image)),image);
vm.runInContext('query="mahua";render()',ctx);assert.equal((els.products.innerHTML.match(/<article/g)||[]).length,3);
vm.runInContext('selected.set("9362697879777",1);add("9362697879777");add("9362697879777")',ctx);assert.equal(els.total.textContent,'₹822');
ctx=boot();assert.equal(els['cart-count'].textContent,2);assert.equal(els.total.textContent,'₹822');
storage.set('bundelimart-bag','[{"product":"invalid","quantity":2,"variant":0}]');boot();assert.equal(els['cart-count'].textContent,0);
storage.set('bundelimart-bag','broken JSON');boot();assert.equal(els['cart-count'].textContent,0);
console.log('PASS: all 38 images, search, variant totals, persisted bag and invalid-storage recovery.');
