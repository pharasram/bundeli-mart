# Google Play listing draft

App name: BundeliMart

Short description: Explore Bundelkhand flavours, save your favourites in a bag and contact support.

Full description:

Discover Bundelkhand's regional flavours with BundeliMart. Browse 38 products across six categories, including pickles, sweets, pantry essentials and herbal teas. Compare pack options, search the collection and keep a shopping bag saved on your device.

The collection and product images are available offline. Reach Vindrawan & Sons Food Pvt. Ltd. through the app's call and WhatsApp links when you have questions.

This initial release is a catalog preview. Prices and availability are provisional. Online orders and payments are not currently available. Images are packaging visualizations; actual packaging may vary.

Customer support: +91 8817630295 / +91 8982618970
Address: Village Khumanganj, Palera, Tikamgarh, MP 472221

Release notes: First catalog release with offline browsing, search, pack selection, a saved bag and customer support links.

## Submission information to confirm

Category suggestion: Shopping. Ads: none. Account login: none. Payments: none.
The app code has no analytics, trackers, device permissions or collection backend. The bag stays in device-local WebView storage; uninstalling removes it. External WhatsApp, phone and reference links open another app or browser, where that provider's policy applies. Validate these facts against the final artifact before completing Data Safety.

Required owner inputs: a public privacy-policy URL, support email, registered developer identity and account verification. Complete Google's content-rating and target-audience questionnaires truthfully. Do not claim verified stock or ordering functionality.

Prepare screenshots from the running Android app and a 512px store icon and 1024x500 feature graphic. The source launcher icon is not yet a Play listing asset.
