# BundeliMart Android

Offline Android catalog app: all 38 products and images, searchable categories, pack variants, a saved bag, phone and WhatsApp support, and Android back handling. No login, analytics, device permissions or payment collection. Catalog prices and stock remain provisional.

## Build
Open this android directory in Android Studio. Install JDK 17, Android SDK 36, and Gradle 8.13. Sync the Gradle project. With Gradle available: `gradle :app:assembleDebug :app:lintDebug` produces the test APK under app/build/outputs/apk/debug/. The repository GitHub Actions workflow performs this build without a local SDK.

## Google Play
Application ID: in.bundelimart.app (confirm ownership before the first upload). For publication use Android Studio > Build > Generate Signed App Bundle, select release, create your own upload key, and retain it securely. Supply the signed AAB to your Play Console, complete testing, store listing, privacy-policy URL and data-safety disclosures. No release signing key is stored here. An unsigned release bundle cannot be uploaded. Google Play acceptance is not guaranteed. The preview catalog needs confirmed inventory, prices and policies before a commercial launch.

## Verification
Web catalog checks can run with Node using ../scripts/check-android.cjs. Local Android compilation has not been performed because this workstation has no Java or Android SDK. CI executes Android lint and debug compilation when pushed.
